from django.apps import AppConfig


class ControlsConfig(AppConfig):
    name = 'controls'
