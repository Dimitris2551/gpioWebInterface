from django.contrib import admin
from .models import control
# Register your models here.
admin.site.register(control)